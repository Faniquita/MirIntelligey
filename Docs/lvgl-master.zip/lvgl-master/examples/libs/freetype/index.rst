Create a font with FreeType
---------------------------

.. lv_example:: libs/freetype/lv_example_freetype_1
  :language: c

Use a bitmap font to draw Emojis using FreeType
-----------------------------------------------

.. lv_example:: libs/freetype/lv_example_freetype_2
  :language: c

Freetype font kerning
---------------------

.. lv_example:: libs/freetype/lv_example_freetype_3
  :language: c
